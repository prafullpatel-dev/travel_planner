const express = require('express');
const cors = require('cors');
const axios = require('axios');
const { randomUUID } = require('crypto');

const app = express();
app.use(cors());
app.use(express.json());

// In-memory store — no database needed
let trips = {};

const calculateBudget = (trip) => {
  let totalEstimated = 0;
  let totalActual = 0;
  trip.days.forEach((day) => {
    day.activities.forEach((act) => {
      totalEstimated += act.estimatedCost || 0;
      totalActual += act.actualCost || 0;
    });
  });
  const remaining = trip.budget - totalActual;
  return {
    budget: trip.budget,
    totalEstimated,
    totalActual,
    remaining,
    percentUsed: trip.budget > 0 ? Math.min(Math.round((totalActual / trip.budget) * 100), 100) : 0,
    overBudget: totalActual > trip.budget,
  };
};

const withBudget = (trip) => ({ ...trip, budgetSummary: calculateBudget(trip) });

// Create trip
app.post('/api/trips', (req, res) => {
  const id = randomUUID();
  const trip = {
    _id: id,
    tripName: req.body.tripName,
    budget: Number(req.body.budget),
    destinations: [],
    days: [],
    createdAt: new Date().toISOString(),
  };
  trips[id] = trip;
  res.status(201).json(withBudget(trip));
});

// List trips
app.get('/api/trips', (req, res) => {
  res.json(Object.values(trips).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
});

// Get trip
app.get('/api/trips/:id', (req, res) => {
  const trip = trips[req.params.id];
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  res.json(withBudget(trip));
});

// Add destination
app.post('/api/trips/:id/destinations', (req, res) => {
  const trip = trips[req.params.id];
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  trip.destinations.push({ _id: randomUUID(), notes: '', ...req.body });
  res.json(withBudget(trip));
});

// Update destination notes
app.put('/api/trips/:id/destinations/:destId', (req, res) => {
  const trip = trips[req.params.id];
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const dest = trip.destinations.find((d) => d._id === req.params.destId);
  if (!dest) return res.status(404).json({ error: 'Destination not found' });
  dest.notes = req.body.notes;
  res.json(withBudget(trip));
});

// Add day
app.post('/api/trips/:id/days', (req, res) => {
  const trip = trips[req.params.id];
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  trip.days.push({ _id: randomUUID(), date: req.body.date, activities: [] });
  trip.days.sort((a, b) => new Date(a.date) - new Date(b.date));
  res.json(withBudget(trip));
});

// Add activity
app.post('/api/trips/:id/days/:dayId/activities', (req, res) => {
  const trip = trips[req.params.id];
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const day = trip.days.find((d) => d._id === req.params.dayId);
  if (!day) return res.status(404).json({ error: 'Day not found' });
  day.activities.push({ _id: randomUUID(), actualCost: 0, ...req.body });
  res.json(withBudget(trip));
});

// Update activity costs
app.put('/api/trips/:id/days/:dayId/activities/:actId', (req, res) => {
  const trip = trips[req.params.id];
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const day = trip.days.find((d) => d._id === req.params.dayId);
  if (!day) return res.status(404).json({ error: 'Day not found' });
  const act = day.activities.find((a) => a._id === req.params.actId);
  if (!act) return res.status(404).json({ error: 'Activity not found' });
  if (req.body.estimatedCost !== undefined) act.estimatedCost = Number(req.body.estimatedCost);
  if (req.body.actualCost !== undefined) act.actualCost = Number(req.body.actualCost);
  res.json(withBudget(trip));
});

// Places search — Nominatim, free, no key
app.post('/api/places/search', async (req, res) => {
  const { query } = req.body;
  if (!query) return res.status(400).json({ error: 'query is required' });
  try {
    const response = await axios.get('https://nominatim.openstreetmap.org/search', {
      params: { q: query, format: 'json', limit: 6, addressdetails: 1 },
      headers: { 'User-Agent': 'TravelPlannerApp/1.0' },
    });
    res.json(
      response.data.map((p) => ({
        name: p.display_name.split(',')[0].trim(),
        placeId: p.place_id.toString(),
        lat: parseFloat(p.lat),
        lng: parseFloat(p.lon),
        address: p.display_name,
      }))
    );
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// AI Itinerary Generator — template based, no key
app.post('/api/ai/generate', (req, res) => {
  const { tripId, destination, days, budget } = req.body;
  const trip = trips[tripId];
  if (!trip) return res.status(404).json({ error: 'Trip not found' });

  const numDays = Number(days) || 3;
  const perDay = Math.round((Number(budget) || trip.budget) / numDays);

  const morning = [
    { name: `Explore ${destination} Old Town`, factor: 0.1 },
    { name: `${destination} Heritage Walk`, factor: 0.05 },
    { name: `Visit Local Market in ${destination}`, factor: 0.15 },
    { name: `${destination} Museum Visit`, factor: 0.12 },
    { name: `Morning at ${destination} Viewpoint`, factor: 0.05 },
  ];
  const afternoon = [
    { name: `Lunch at ${destination} Local Restaurant`, factor: 0.2 },
    { name: `${destination} City Sightseeing`, factor: 0.25 },
    { name: `Shopping at ${destination} Bazaar`, factor: 0.2 },
    { name: `Historical Sites of ${destination}`, factor: 0.15 },
    { name: `${destination} Adventure Activity`, factor: 0.3 },
  ];
  const evening = [
    { name: `Sunset at ${destination} Viewpoint`, factor: 0.05 },
    { name: `${destination} Street Food Tour`, factor: 0.15 },
    { name: `Dinner at ${destination} Rooftop`, factor: 0.2 },
    { name: `${destination} Night Market`, factor: 0.1 },
    { name: `Cultural Show in ${destination}`, factor: 0.15 },
  ];

  const today = new Date();
  for (let i = 0; i < numDays; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    trip.days.push({
      _id: randomUUID(),
      date: date.toISOString().split('T')[0],
      activities: [
        { _id: randomUUID(), name: morning[i % morning.length].name, estimatedCost: Math.round(perDay * morning[i % morning.length].factor), actualCost: 0 },
        { _id: randomUUID(), name: afternoon[i % afternoon.length].name, estimatedCost: Math.round(perDay * afternoon[i % afternoon.length].factor), actualCost: 0 },
        { _id: randomUUID(), name: evening[i % evening.length].name, estimatedCost: Math.round(perDay * evening[i % evening.length].factor), actualCost: 0 },
      ],
    });
  }
  trip.days.sort((a, b) => new Date(a.date) - new Date(b.date));
  res.json(withBudget(trip));
});

// Chatbot — rule based, no key
app.post('/api/ai/chat', (req, res) => {
  const { tripId, message } = req.body;
  const trip = trips[tripId];
  if (!trip) return res.status(404).json({ error: 'Trip not found' });

  const msg = message.toLowerCase();
  const b = calculateBudget(trip);
  const totalActivities = trip.days.reduce((acc, d) => acc + d.activities.length, 0);

  let reply;

  if (msg.includes('budget') || msg.includes('money') || msg.includes('spend') || msg.includes('cost')) {
    reply = b.overBudget
      ? `⚠️ Over budget by ₹${Math.abs(b.remaining).toLocaleString()}! Spent ₹${b.totalActual.toLocaleString()} of ₹${b.budget.toLocaleString()}.`
      : `💰 On track! Spent ₹${b.totalActual.toLocaleString()} of ₹${b.budget.toLocaleString()}. ₹${b.remaining.toLocaleString()} remaining.`;
  } else if (msg.includes('activity') || msg.includes('plan')) {
    reply = `📋 ${totalActivities} activities across ${trip.days.length} day(s). Estimated total: ₹${b.totalEstimated.toLocaleString()}.`;
  } else if (msg.includes('destination') || msg.includes('place')) {
    reply = trip.destinations.length === 0
      ? `🗺️ No destinations yet. Search on the map and click + Add.`
      : `📍 ${trip.destinations.length} destination(s): ${trip.destinations.map((d) => d.name).join(', ')}.`;
  } else if (msg.includes('pack') || msg.includes('bring')) {
    reply = `🎒 Pack: comfortable shoes, weather-appropriate clothes, power bank, travel adapter, copy of IDs, medications, first-aid kit.`;
  } else if (msg.includes('save') || msg.includes('cheap')) {
    reply = `💸 Save money: eat local, use public transport, visit free parks and markets, book activities in advance.`;
  } else if (msg.includes('tip') || msg.includes('advice')) {
    reply = `💡 Tips: Carry local cash, download offline maps, try street food, keep emergency contacts saved.`;
  } else if (msg.includes('hi') || msg.includes('hello') || msg.includes('hey')) {
    reply = `👋 Hi! I'm your assistant for "${trip.tripName}". Ask me about budget, activities, packing, or travel tips!`;
  } else {
    reply = `🤔 I can help with budget status, activity planning, packing tips, and travel advice for "${trip.tripName}".`;
  }

  res.json({ reply });
});

app.listen(5000, () => {
  console.log('Server running at http://localhost:5000');
});
