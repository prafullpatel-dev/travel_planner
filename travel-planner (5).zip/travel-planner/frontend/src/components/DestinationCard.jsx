import React, { useState } from 'react';

export default function DestinationCard({ destination, onUpdateNotes }) {
  const [editing, setEditing] = useState(false);
  const [notes, setNotes] = useState(destination.notes || '');

  const handleSave = () => {
    onUpdateNotes(notes);
    setEditing(false);
  };

  return (
    <div className="bg-white rounded-xl shadow p-4 w-52 flex-shrink-0 border border-gray-100">
      <h3 className="font-bold text-sm truncate mb-1" title={destination.name}>
        📌 {destination.name}
      </h3>
      <p className="text-xs text-gray-400 truncate mb-2">{destination.address}</p>

      {editing ? (
        <>
          <textarea
            className="w-full border rounded p-1 text-xs resize-none mb-1"
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add notes..."
            autoFocus
          />
          <div className="flex gap-1">
            <button onClick={handleSave} className="bg-blue-600 text-white text-xs px-2 py-1 rounded">
              Save
            </button>
            <button onClick={() => setEditing(false)} className="border text-xs px-2 py-1 rounded">
              Cancel
            </button>
          </div>
        </>
      ) : (
        <>
          <p className="text-xs text-gray-500 mb-2 min-h-[32px]">{notes || 'No notes yet.'}</p>
          <button onClick={() => setEditing(true)} className="text-xs text-blue-600 hover:underline">
            {notes ? '✏ Edit notes' : '+ Add notes'}
          </button>
        </>
      )}
    </div>
  );
}
