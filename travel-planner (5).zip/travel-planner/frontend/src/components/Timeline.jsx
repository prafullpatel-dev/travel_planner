import React, { useState } from 'react';

export default function Timeline({ days, onAddDay, onAddActivity, onUpdateActivity }) {
  const [newDate, setNewDate] = useState('');
  const [forms, setForms] = useState({});

  const handleAddDay = () => {
    if (!newDate) return;
    onAddDay(newDate);
    setNewDate('');
  };

  const handleAddActivity = (dayId) => {
    const f = forms[dayId] || {};
    if (!f.name?.trim()) return;
    onAddActivity(dayId, { name: f.name.trim(), estimatedCost: Number(f.cost || 0), actualCost: 0 });
    setForms((p) => ({ ...p, [dayId]: {} }));
  };

  const sorted = [...days].sort((a, b) => new Date(a.date) - new Date(b.date));

  return (
    <div className="p-4">
      <div className="flex items-center gap-2 mb-6">
        <h2 className="font-bold text-lg flex-1">Itinerary</h2>
        <input
          type="date"
          className="border rounded px-2 py-1 text-sm"
          value={newDate}
          onChange={(e) => setNewDate(e.target.value)}
        />
        <button
          onClick={handleAddDay}
          className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
        >
          + Day
        </button>
      </div>

      {sorted.length === 0 && (
        <p className="text-gray-400 text-sm text-center py-16">
          Add a day to start your itinerary.<br />Or use ✨ AI Generate.
        </p>
      )}

      {sorted.map((day, idx) => (
        <div key={day._id} className="mb-8 relative">
          {idx < sorted.length - 1 && (
            <div className="absolute left-3 top-7 bottom-[-16px] w-0.5 bg-blue-200" />
          )}

          <div className="flex items-center gap-3 mb-3">
            <div className="w-7 h-7 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center z-10 flex-shrink-0">
              {idx + 1}
            </div>
            <h3 className="font-semibold text-sm text-gray-700">
              {new Date(day.date).toLocaleDateString('en-IN', {
                weekday: 'long', day: 'numeric', month: 'short', year: 'numeric',
              })}
            </h3>
          </div>

          <div className="ml-10 space-y-2">
            {day.activities.map((act) => (
              <div key={act._id} className="bg-white rounded-lg shadow-sm p-3 border border-gray-100">
                <p className="font-medium text-sm mb-2">📍 {act.name}</p>
                <div className="flex gap-3 flex-wrap">
                  <div>
                    <label className="block text-xs text-gray-500 mb-0.5">Estimated (₹)</label>
                    <input
                      type="number" min="0"
                      className="w-28 border rounded px-2 py-1 text-sm"
                      defaultValue={act.estimatedCost}
                      onBlur={(e) => onUpdateActivity(day._id, act._id, {
                        estimatedCost: Number(e.target.value),
                        actualCost: act.actualCost,
                      })}
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-0.5">Actual (₹)</label>
                    <input
                      type="number" min="0"
                      className="w-28 border rounded px-2 py-1 text-sm"
                      defaultValue={act.actualCost}
                      onBlur={(e) => onUpdateActivity(day._id, act._id, {
                        estimatedCost: act.estimatedCost,
                        actualCost: Number(e.target.value),
                      })}
                    />
                  </div>
                </div>
              </div>
            ))}

            <div className="border border-dashed border-gray-300 rounded-lg p-2 bg-gray-50">
              <input
                type="text"
                placeholder="Activity name"
                className="w-full border rounded px-2 py-1 text-sm mb-1"
                value={forms[day._id]?.name || ''}
                onChange={(e) => setForms((p) => ({ ...p, [day._id]: { ...p[day._id], name: e.target.value } }))}
              />
              <div className="flex gap-2">
                <input
                  type="number" min="0"
                  placeholder="Est. cost (₹)"
                  className="flex-1 border rounded px-2 py-1 text-sm"
                  value={forms[day._id]?.cost || ''}
                  onChange={(e) => setForms((p) => ({ ...p, [day._id]: { ...p[day._id], cost: e.target.value } }))}
                />
                <button
                  onClick={() => handleAddActivity(day._id)}
                  className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700"
                >
                  + Add
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
