import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import api from '../api/index';

// Fix broken marker icons in Vite
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const redIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34],
});

const blueIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34],
});

function Recenter({ center }) {
  const map = useMap();
  useEffect(() => { map.setView(center, 12); }, [center, map]);
  return null;
}

export default function Map({ destinations, activities, onAddDestination }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [center, setCenter] = useState([20.5937, 78.9629]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const { data } = await api.post('/places/search', { query });
      setResults(data);
      if (data.length > 0) setCenter([data[0].lat, data[0].lng]);
    } catch {
      alert('Search failed. Check internet connection.');
    }
    setLoading(false);
  };

  const handleAdd = (place) => {
    onAddDestination(place);
    setResults([]);
    setQuery('');
    setCenter([place.lat, place.lng]);
  };

  return (
    // isolation:isolate keeps Leaflet z-indexes contained so modals appear on top
    <div className="relative w-full h-full" style={{ isolation: 'isolate' }}>

      {/* Search bar */}
      <div className="absolute top-2 left-2 right-2 flex gap-2" style={{ zIndex: 400 }}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          placeholder="Search places..."
          className="flex-1 px-3 py-2 rounded-lg shadow text-sm border focus:outline-none focus:ring-2 focus:ring-blue-400 bg-white"
        />
        <button
          onClick={handleSearch}
          disabled={loading}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 disabled:opacity-50 shadow"
        >
          {loading ? '...' : 'Search'}
        </button>
      </div>

      {/* Results dropdown */}
      {results.length > 0 && (
        <div
          className="absolute top-14 left-2 right-2 bg-white rounded-lg shadow-xl max-h-52 overflow-y-auto border"
          style={{ zIndex: 400 }}
        >
          {results.map((p) => (
            <div key={p.placeId} className="flex items-start justify-between p-3 hover:bg-gray-50 border-b last:border-0">
              <div className="flex-1 min-w-0 mr-2">
                <p className="font-medium text-sm truncate">{p.name}</p>
                <p className="text-xs text-gray-400 truncate">{p.address}</p>
              </div>
              <button
                onClick={() => handleAdd(p)}
                className="bg-blue-600 text-white text-xs px-3 py-1 rounded flex-shrink-0 hover:bg-blue-700"
              >
                + Add
              </button>
            </div>
          ))}
          <button onClick={() => setResults([])} className="w-full text-xs text-gray-400 py-2 hover:bg-gray-50">
            Close
          </button>
        </div>
      )}

      {/* Map */}
      <MapContainer center={center} zoom={5} style={{ height: '100%', width: '100%', zIndex: 0 }}>
        <Recenter center={center} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {destinations.filter((d) => d.lat && d.lng).map((d, i) => (
          <Marker key={i} position={[d.lat, d.lng]} icon={redIcon}>
            <Popup>
              <strong>{d.name}</strong>
              <br />
              <span className="text-xs">{d.address}</span>
            </Popup>
          </Marker>
        ))}
        {activities.filter((a) => a.lat && a.lng).map((a, i) => (
          <Marker key={i} position={[a.lat, a.lng]} icon={blueIcon}>
            <Popup>
              <strong>{a.name}</strong>
              {a.estimatedCost > 0 && <><br /><span className="text-xs">Est: ₹{a.estimatedCost}</span></>}
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Legend */}
      <div className="absolute bottom-2 left-2 bg-white rounded shadow px-3 py-2 text-xs space-y-1" style={{ zIndex: 400 }}>
        <div>🔴 Destinations</div>
        <div>🔵 Activities</div>
      </div>
    </div>
  );
}
