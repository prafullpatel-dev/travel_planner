import React from 'react';

export default function BudgetBar({ summary }) {
  if (!summary) return null;
  const { budget, totalEstimated, totalActual, remaining, percentUsed, overBudget } = summary;

  return (
    <div>
      <div className="flex justify-between text-sm font-medium mb-1 flex-wrap gap-2">
        <span className="text-gray-600">Budget: ₹{budget.toLocaleString()}</span>
        <span className="text-blue-600">Estimated: ₹{totalEstimated.toLocaleString()}</span>
        <span className="text-orange-500">Spent: ₹{totalActual.toLocaleString()}</span>
        <span className={overBudget ? 'text-red-600 font-bold' : 'text-green-600 font-bold'}>
          {overBudget
            ? `⚠ Over by ₹${Math.abs(remaining).toLocaleString()}`
            : `Remaining: ₹${remaining.toLocaleString()}`}
        </span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-5 overflow-hidden">
        <div
          style={{ width: `${percentUsed}%` }}
          className={`h-5 rounded-full transition-all duration-500 ${
            overBudget ? 'bg-red-500' : percentUsed > 80 ? 'bg-orange-400' : 'bg-green-500'
          }`}
        />
      </div>
      <div className="flex justify-between text-xs text-gray-400 mt-1">
        <span>0%</span>
        <span>{percentUsed}% used</span>
        <span>100%</span>
      </div>
    </div>
  );
}
