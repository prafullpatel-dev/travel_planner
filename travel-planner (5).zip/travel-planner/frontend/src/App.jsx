import React, { useState, useEffect } from 'react';
import api from './api/index';
import BudgetBar from './components/BudgetBar';
import Map from './components/Map';
import Timeline from './components/Timeline';
import DestinationCard from './components/DestinationCard';

export default function App() {
  const [trips, setTrips] = useState([]);
  const [trip, setTrip] = useState(null);

  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ tripName: '', budget: '' });

  const [showAI, setShowAI] = useState(false);
  const [aiForm, setAiForm] = useState({ destination: '', days: 3, budget: '', interests: '' });
  const [aiLoading, setAiLoading] = useState(false);

  const [chatOpen, setChatOpen] = useState(false);
  const [chatHistory, setChatHistory] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);

  useEffect(() => { loadTrips(); }, []);

  const loadTrips = async () => {
    const { data } = await api.get('/trips');
    setTrips(data);
  };

  const loadTrip = async (id) => {
    const { data } = await api.get(`/trips/${id}`);
    setTrip(data);
  };

  const handleCreate = async () => {
    if (!form.tripName || !form.budget) return;
    const { data } = await api.post('/trips', {
      tripName: form.tripName,
      budget: Number(form.budget),
    });
    setTrips((p) => [data, ...p]);
    setTrip(data);
    setShowCreate(false);
    setForm({ tripName: '', budget: '' });
  };

  const handleAddDestination = async (place) => {
    await api.post(`/trips/${trip._id}/destinations`, place);
    loadTrip(trip._id);
  };

  const handleUpdateNotes = async (destId, notes) => {
    await api.put(`/trips/${trip._id}/destinations/${destId}`, { notes });
    loadTrip(trip._id);
  };

  const handleAddDay = async (date) => {
    await api.post(`/trips/${trip._id}/days`, { date });
    loadTrip(trip._id);
  };

  const handleAddActivity = async (dayId, activity) => {
    await api.post(`/trips/${trip._id}/days/${dayId}/activities`, activity);
    loadTrip(trip._id);
  };

  const handleUpdateActivity = async (dayId, actId, data) => {
    await api.put(`/trips/${trip._id}/days/${dayId}/activities/${actId}`, data);
    loadTrip(trip._id);
  };

  const handleGenerate = async () => {
    if (!aiForm.destination) return;
    setAiLoading(true);
    try {
      const { data } = await api.post('/ai/generate', {
        tripId: trip._id,
        destination: aiForm.destination,
        days: Number(aiForm.days),
        budget: Number(aiForm.budget || trip.budget),
        interests: aiForm.interests,
      });
      setTrip(data);
      setShowAI(false);
      setAiForm({ destination: '', days: 3, budget: '', interests: '' });
    } catch (err) {
      alert('Generation failed: ' + err.message);
    }
    setAiLoading(false);
  };

  const handleChat = async () => {
    if (!chatInput.trim() || chatLoading) return;
    const userMsg = { role: 'user', content: chatInput };
    const updated = [...chatHistory, userMsg];
    setChatHistory(updated);
    setChatInput('');
    setChatLoading(true);
    try {
      const { data } = await api.post('/ai/chat', { tripId: trip._id, message: chatInput });
      setChatHistory([...updated, { role: 'assistant', content: data.reply }]);
    } catch {
      setChatHistory([...updated, { role: 'assistant', content: 'Something went wrong. Try again.' }]);
    }
    setChatLoading(false);
  };

  // ── Trip List Screen ───────────────────────────────────────────────────────
  if (!trip) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold text-blue-700">✈ Travel Planner</h1>
            <button
              onClick={() => setShowCreate(true)}
              className="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700 font-medium"
            >
              + New Trip
            </button>
          </div>

          {trips.length === 0 && (
            <div className="text-center py-24 text-gray-400">
              <p className="text-5xl mb-4">🗺</p>
              <p className="text-lg">No trips yet. Create your first one!</p>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {trips.map((t) => (
              <div
                key={t._id}
                onClick={() => loadTrip(t._id)}
                className="bg-white rounded-xl shadow p-5 cursor-pointer hover:shadow-md border border-transparent hover:border-blue-300 transition-all"
              >
                <h2 className="font-bold text-lg mb-1">{t.tripName}</h2>
                <p className="text-gray-500 text-sm">Budget: ₹{Number(t.budget).toLocaleString()}</p>
                <p className="text-gray-400 text-xs mt-1">
                  {new Date(t.createdAt).toLocaleDateString('en-IN')}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Create Trip Modal */}
        {showCreate && (
          <div
            className="fixed inset-0 bg-black/50 flex items-center justify-center"
            style={{ zIndex: 99999 }}
          >
            <div className="bg-white rounded-xl shadow-2xl p-6 w-80">
              <h2 className="font-bold text-xl mb-4">New Trip</h2>
              <input
                type="text"
                placeholder="Trip name (e.g. Goa 2025)"
                className="w-full border rounded-lg px-3 py-2 mb-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                value={form.tripName}
                onChange={(e) => setForm({ ...form, tripName: e.target.value })}
                onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
              />
              <input
                type="number"
                placeholder="Total budget (₹)"
                className="w-full border rounded-lg px-3 py-2 mb-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                value={form.budget}
                onChange={(e) => setForm({ ...form, budget: e.target.value })}
                onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
              />
              <div className="flex gap-2">
                <button
                  onClick={handleCreate}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium"
                >
                  Create
                </button>
                <button
                  onClick={() => setShowCreate(false)}
                  className="flex-1 border py-2 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ── Main Trip View ─────────────────────────────────────────────────────────
  const allActivities = trip.days.flatMap((d) => d.activities);

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-gray-100">

      {/* Header */}
      <div className="bg-white shadow-sm px-6 py-3 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-4">
          <button
            onClick={() => { setTrip(null); setChatHistory([]); }}
            className="text-blue-600 hover:underline text-sm"
          >
            ← Trips
          </button>
          <h1 className="font-bold text-xl">✈ {trip.tripName}</h1>
        </div>
        <button
          onClick={() => setShowAI(true)}
          className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 text-sm font-medium"
        >
          ✨ AI Generate Itinerary
        </button>
      </div>

      {/* Budget Bar */}
      <div className="bg-white border-b px-6 py-3 flex-shrink-0">
        <BudgetBar summary={trip.budgetSummary} />
      </div>

      {/* Map + Timeline */}
      <div className="flex flex-1 overflow-hidden">
        <div className="w-1/2 relative">
          <Map
            destinations={trip.destinations}
            activities={allActivities}
            onAddDestination={handleAddDestination}
          />
        </div>
        <div className="w-1/2 overflow-y-auto border-l bg-gray-50">
          <Timeline
            days={trip.days}
            onAddDay={handleAddDay}
            onAddActivity={handleAddActivity}
            onUpdateActivity={handleUpdateActivity}
          />
        </div>
      </div>

      {/* Destination Cards */}
      <div className="bg-white border-t px-6 py-4 flex-shrink-0">
        <h2 className="font-bold text-base mb-3">Destinations</h2>
        <div className="flex gap-3 overflow-x-auto pb-1">
          {trip.destinations.length === 0 ? (
            <p className="text-gray-400 text-sm py-2">
              Search for a place on the map and click "+ Add".
            </p>
          ) : (
            trip.destinations.map((dest) => (
              <DestinationCard
                key={dest._id}
                destination={dest}
                onUpdateNotes={(notes) => handleUpdateNotes(dest._id, notes)}
              />
            ))
          )}
        </div>
      </div>

      {/* AI Generate Modal — high z-index to sit above Leaflet map */}
      {showAI && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center"
          style={{ zIndex: 99999 }}
        >
          <div className="bg-white rounded-xl shadow-2xl p-6 w-96">
            <h2 className="font-bold text-xl mb-1">✨ AI Itinerary Generator</h2>
            <p className="text-xs text-gray-400 mb-4">Fills your timeline automatically.</p>
            <input
              type="text"
              placeholder="Destination (e.g. Goa, Manali)"
              className="w-full border rounded-lg px-3 py-2 mb-3 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
              value={aiForm.destination}
              onChange={(e) => setAiForm({ ...aiForm, destination: e.target.value })}
            />
            <input
              type="number"
              placeholder="Number of days"
              min="1" max="14"
              className="w-full border rounded-lg px-3 py-2 mb-3 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
              value={aiForm.days}
              onChange={(e) => setAiForm({ ...aiForm, days: e.target.value })}
            />
            <input
              type="number"
              placeholder={`Budget ₹ (default: ${trip.budget})`}
              className="w-full border rounded-lg px-3 py-2 mb-3 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
              value={aiForm.budget}
              onChange={(e) => setAiForm({ ...aiForm, budget: e.target.value })}
            />
            <input
              type="text"
              placeholder="Interests (e.g. beaches, food, history)"
              className="w-full border rounded-lg px-3 py-2 mb-4 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
              value={aiForm.interests}
              onChange={(e) => setAiForm({ ...aiForm, interests: e.target.value })}
            />
            <div className="flex gap-2">
              <button
                onClick={handleGenerate}
                disabled={aiLoading}
                className="flex-1 bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 disabled:opacity-50 font-medium"
              >
                {aiLoading ? 'Generating...' : 'Generate'}
              </button>
              <button
                onClick={() => setShowAI(false)}
                className="flex-1 border py-2 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chatbot */}
      <div className="fixed bottom-5 right-5" style={{ zIndex: 99999 }}>
        {chatOpen ? (
          <div className="bg-white rounded-2xl shadow-2xl w-80 h-96 flex flex-col border">
            <div className="bg-blue-600 text-white px-4 py-3 rounded-t-2xl flex justify-between items-center">
              <span className="font-bold text-sm">💬 Trip Assistant</span>
              <button onClick={() => setChatOpen(false)} className="text-lg leading-none hover:text-blue-200">
                ×
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {chatHistory.length === 0 && (
                <div className="text-gray-400 text-xs text-center pt-4 space-y-1">
                  <p>Ask me about your trip!</p>
                  <p>💰 "What's my budget status?"</p>
                  <p>📋 "How many activities?"</p>
                  <p>🎒 "What should I pack?"</p>
                  <p>💸 "How can I save money?"</p>
                </div>
              )}
              {chatHistory.map((msg, i) => (
                <div
                  key={i}
                  className={`text-xs rounded-lg p-2 ${
                    msg.role === 'user' ? 'bg-blue-100 ml-6 text-right' : 'bg-gray-100 mr-6'
                  }`}
                >
                  {msg.content}
                </div>
              ))}
              {chatLoading && (
                <div className="bg-gray-100 text-xs rounded-lg p-2 mr-6 text-gray-400 animate-pulse">
                  Thinking...
                </div>
              )}
            </div>
            <div className="border-t p-3 flex gap-2">
              <input
                type="text"
                placeholder="Ask about your trip..."
                className="flex-1 border rounded-lg px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-blue-400"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleChat()}
              />
              <button
                onClick={handleChat}
                disabled={chatLoading}
                className="bg-blue-600 text-white px-3 py-1 rounded-lg text-xs hover:bg-blue-700 disabled:opacity-50"
              >
                Send
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setChatOpen(true)}
            className="bg-blue-600 text-white p-4 rounded-full shadow-xl hover:bg-blue-700 text-xl"
          >
            💬
          </button>
        )}
      </div>
    </div>
  );
}
